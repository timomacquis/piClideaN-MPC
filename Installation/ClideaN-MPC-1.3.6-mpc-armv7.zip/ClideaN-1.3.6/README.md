# πClideaN — 1.3.6

A sixteen-lane MIDI-only sequencer with Euclidean rhythms, per-step expression, polymetric cycles, scales and dual-LFO modulation.

Guided ALTER, per-lane A/B and coordinated **Rdm 8** generation complement selective RAND. Seven native programs are included; INIT leaves lanes 9–16 empty.

Version 1.3.6 adds compact selection panels over the current screen, with a dim overlay, yellow openers and 36 px panel buttons. Typography remains labels 18, rotary values 30. The sequencing engine, parameter indices and project format are unchanged from 1.3.4.

Separate Gen1 ARMv7 and Gen2 AArch64 packages are provided. The font-only update was accepted on the author's Force; Gen2 remains untested on hardware. No new exact-release install/uninstall qualification is claimed.

See the included English/French manuals. Compact offline-extracted GMD preferences guide generation; no raw dataset or neural runtime is embedded. Keep original project copies before downgrading.
