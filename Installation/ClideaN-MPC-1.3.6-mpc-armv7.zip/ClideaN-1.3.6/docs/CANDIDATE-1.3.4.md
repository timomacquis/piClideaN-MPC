# πClideaN 1.3.4-candidate.4

Gen1 ARM32-only local candidate. Not installed or published. Candidate.3 was installed on Force; the Gen2 candidate.2 archive is unchanged.

## VARIATIONS

RAND retains the existing two-stage parameter-selection workflow. A separate VAR button opens VARIATIONS immediately. No long press is used. Candidate.3 device feedback showed that both short and long presses opened VARIATIONS; candidate.4 removes that gesture dependency.

A/B stores two rhythmic variants for each line: STEPS/HITS/ROTATE/DIVISION, trigger overrides, per-step velocity/probability/ratchet/decay and GATE. Notes, LINE settings, HOLD, traversal/autorotation, MOD and runtime clocks remain shared. COPY A → B replaces B with A. Starting ALTER from A preserves A and prepares its result in B.

Choose the allowed parameters and LIGHT/MEDIUM/FREE. The engine evaluates up to 64 candidates using cyclic resemblance, existing anchor preservation, density and silence spacing. Step locks stay at their original step indices, including temporarily hidden steps when shortening a line. Forced triggers are preserved; incompatible density constraints cause a no-op, not silent lock deletion. FREE still respects protected fields and 75% effective attack density (ratchet sub-notes are not counted as separate active steps).

## Rdm 8

Replaces the old Rd ALL scope with coordinated generation of lines 01–08. A shared onset-occupancy grid guides complementary rotations and sparse temporary rhythmic roles; no fixed drum names or harmonic interpretation. This is an original rule-based first implementation, not a neural model or a guarantee of musical preference.

Notes and MUTE are preserved. On 01–08, LINE resets to velocity/probability 100, humanize 0 and GATE 50; per-step edits, A/B, HOLD, traversal/autorotation and assigned MOD are reset. **09–16 and their MOD/A/B remain untouched.** All sixteen lines remain silent in INIT; generation is explicit.

## Timing and persistence

Candidate search runs on a worker using immutable input copies. Result application is bounded and rejects stale results after control/context changes. Only affected MIDI lanes are released; shared transport origins remain intact. Ordinary edits keep targeted notifications and the wrapper budget of eight.

PICN8 stores alternate variants compactly, within the existing 32 KiB chunk. Older PICN1–7 states and factory programs remain readable; older binaries do not understand PICN8. Keep original project copies before device evaluation. No parameter index added, reordered or removed (4096 unchanged slots).

The native touch targets, displayed A/B states, MIDI during live switching and absence of crackles still require hardware testing. Gen2 qualification remains separate.

## Groove-derived preferences

Candidate.2 adds 457 bytes of offline-extracted GMD statistics to guide spacing, compatible metric phases, density sampling and pair overlaps. No raw dataset or neural runtime is embedded. Same interface and safeguards. [Method, attribution and limits](GROOVE-STATISTICS.md).

## Candidate.3 — UI corrections, Gen1 only

- Centre PATTERN labels horizontally, retaining Titillium Web Regular 18 px and vertical placement.
- Centre PATTERN LINE/EDIT/RAND values horizontally, height 21, same vertical bounds.
- Use native height 22 for MOD selection fields (including destinations), track MODE/SHIFT-STEPS/EVERY-CYCLES, CONFIG SCALES/START/COUNT-IN/MIDI notes, and VARIATIONS status text.
- Correct VARIATIONS previews with 128 complete frames and repeated state plateaus, preserving all 18 state colours and both 16-step rows. Same 32 passive controls.
- Engine algorithm sources, MIDI paths, parameter indices and Q-Links unchanged from candidate.2.

Only a Gen1 ZIP is prepared for this correction. Real Force text sizing and preview rendering still require an authorized installation and visual check.

## Candidate.4 — separate RAND and VAR

LINE row: LINE | EDIT | MUTE | SOLO | 1/2 + x2 | VAR | Rdm 8 | RAND. The speed controls share one 148 px slot (70 px each, 8 px gap). Other buttons retain their full width. EDIT layout is unchanged.

RAND has one Toggle Switch touch owner and two cached state images. VAR reuses the existing undo action index as a wrapper-released momentary trigger. No new parameter, timer, worker or image polling is added; the long-press check is removed from transport updates. Generation algorithms and A/B persistence are unchanged. Device touch response and audio continuity remain to be validated.
